=== KROK PO KROKU – MONITOR RYNKU MEXC Z API DLA GPT ===

1. Wymagania
------------
Musisz mieć zainstalowane:
- Python 3.10+
- pip

2. Zainstaluj wymagane biblioteki
----------------------------------
W terminalu uruchom:
    pip install -r requirements.txt

3. Uruchom monitor rynku (pierwsze okno terminala)
---------------------------------------------------
    python market_monitor_full.py

Skrypt analizuje świeczki M5, M15, H1, H4 (co 4h), D1 (o 02:00 lokalnego czasu).

Dane są zapisywane do market_data.json + alerts.json

4. Uruchom serwer API (drugie okno terminala)
---------------------------------------------
    uvicorn api_server:app --reload

Dostępny pod adresem:
    http://127.0.0.1:8000/market-context

5. (Opcjonalnie) Udostępnij przez ngrok
----------------------------------------
    ngrok http 8000

Gotowy link np: https://abc123.ngrok-free.app/market-context
Możesz podłączyć go do GPT jako akcję.

Gotowe!